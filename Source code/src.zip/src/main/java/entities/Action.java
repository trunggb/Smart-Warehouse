package entities;

public enum Action {
	ADD,
	UPDATE,
	DELETE
}

package entities;

public enum Role {
	ADMIN,
	USER,
	DRIVER
}

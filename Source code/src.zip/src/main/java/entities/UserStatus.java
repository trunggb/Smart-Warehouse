package entities;

public enum UserStatus {
	ACTIVE,
	BLOCKED,
	INITIAL
}

package services;

import entities.Bot;

public class BotService extends GenericService<Bot>{
	public BotService() {
		super();
	}

}

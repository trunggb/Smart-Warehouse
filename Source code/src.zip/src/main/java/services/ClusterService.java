package services;

import entities.Cluster;

public class ClusterService extends GenericService<Cluster>{
	public ClusterService() {
		super();
	}
}

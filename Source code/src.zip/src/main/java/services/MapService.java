package services;

import javax.ejb.Stateless;

import entities.Bot;
import entities.Location;
import entities.Map;

@Stateless
public class MapService extends GenericService<Map> {
	public void init() {
		
	}
	
	public void addPath(Bot bot, Location destination) {
		
	}
	
	public void removePath(Bot bot, Location visited) {
		
	}
	
	public void removeAllPath(Bot bot) {
		
	}
	
	public void display() {
		
	}
}

package services;

import entities.Travel;

public class TravelService extends GenericService<Travel>{
	public TravelService() {
		super();
	}
}

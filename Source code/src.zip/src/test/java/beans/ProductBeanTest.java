package beans;


import org.junit.Test;

public class ProductBeanTest {
	@Test
	public void test() {
		
	}
}
